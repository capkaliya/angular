import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-complaint-register-form',
  templateUrl: './citizen-complaint-register-form.component.html',
  styleUrls: ['./citizen-complaint-register-form.component.css']
})
export class CitizenComplaintRegisterFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
