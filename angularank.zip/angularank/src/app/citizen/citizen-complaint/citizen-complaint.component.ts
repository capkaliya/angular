import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-complaint',
  templateUrl: './citizen-complaint.component.html',
  styleUrls: ['./citizen-complaint.component.css']
})
export class CitizenComplaintComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
