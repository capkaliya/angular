import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-complaint-status',
  templateUrl: './citizen-complaint-status.component.html',
  styleUrls: ['./citizen-complaint-status.component.css']
})
export class CitizenComplaintStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
