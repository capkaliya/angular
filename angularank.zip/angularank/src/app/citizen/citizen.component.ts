import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen',
  templateUrl: './citizen.component.html',
  styleUrls: ['./citizen.component.css']
})
export class CitizenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
