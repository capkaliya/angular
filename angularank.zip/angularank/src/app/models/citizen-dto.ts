export class CitizenDTO {
   	 name:any
	 username:any
	 address:any
	 password:any
	 contact:any
}
