import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cdepartment',
  templateUrl: './cdepartment.component.html',
  styleUrls: ['./cdepartment.component.css']
})
export class CdepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
