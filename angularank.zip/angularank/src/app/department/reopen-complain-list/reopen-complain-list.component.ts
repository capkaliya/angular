import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reopen-complain-list',
  templateUrl: './reopen-complain-list.component.html',
  styleUrls: ['./reopen-complain-list.component.css']
})
export class ReopenComplainListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
