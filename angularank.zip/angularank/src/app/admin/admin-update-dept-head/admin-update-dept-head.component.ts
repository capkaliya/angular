import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-update-dept-head',
  templateUrl: './admin-update-dept-head.component.html',
  styleUrls: ['./admin-update-dept-head.component.css']
})
export class AdminUpdateDeptHeadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
