import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-add-dept-head',
  templateUrl: './admin-add-dept-head.component.html',
  styleUrls: ['./admin-add-dept-head.component.css']
})
export class AdminAddDeptHeadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
