import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-department-list',
  templateUrl: './admin-department-list.component.html',
  styleUrls: ['./admin-department-list.component.css']
})
export class AdminDepartmentListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
