import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deptise-complaint',
  templateUrl: './deptise-complaint.component.html',
  styleUrls: ['./deptise-complaint.component.css']
})
export class DeptiseComplaintComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
