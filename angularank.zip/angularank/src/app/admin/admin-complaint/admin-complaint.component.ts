import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-complaint',
  templateUrl: './admin-complaint.component.html',
  styleUrls: ['./admin-complaint.component.css']
})
export class AdminComplaintComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
