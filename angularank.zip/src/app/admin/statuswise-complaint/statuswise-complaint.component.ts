import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-statuswise-complaint',
  templateUrl: './statuswise-complaint.component.html',
  styleUrls: ['./statuswise-complaint.component.css']
})
export class StatuswiseComplaintComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
