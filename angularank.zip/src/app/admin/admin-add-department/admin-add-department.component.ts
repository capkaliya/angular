import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-add-department',
  templateUrl: './admin-add-department.component.html',
  styleUrls: ['./admin-add-department.component.css']
})
export class AdminAddDepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
