import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-dept-head-list',
  templateUrl: './admin-dept-head-list.component.html',
  styleUrls: ['./admin-dept-head-list.component.css']
})
export class AdminDeptHeadListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
