import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csidenav',
  templateUrl: './csidenav.component.html',
  styleUrls: ['./csidenav.component.css']
})
export class CsidenavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
