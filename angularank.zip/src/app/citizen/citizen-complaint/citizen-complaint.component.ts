import { CitizenserviceService } from './../../service/citizenservice.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-complaint',
  templateUrl: './citizen-complaint.component.html',
  styleUrls: ['./citizen-complaint.component.css']
})
export class CitizenComplaintComponent implements OnInit {

  constructor(private citizinService : CitizenserviceService) { }

  ngOnInit(): void {
  }
  sendToForm(msg:string){
this.citizinService.communicateDept(msg);
  }

}
