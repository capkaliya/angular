import { Component, OnInit } from '@angular/core';
import { Subscriber } from 'rxjs';
import { CitizenserviceService } from 'src/app/service/citizenservice.service';

@Component({
  selector: 'app-citizen-complaint-register-form',
  templateUrl: './citizen-complaint-register-form.component.html',
  styleUrls: ['./citizen-complaint-register-form.component.css'],
})
export class CitizenComplaintRegisterFormComponent implements OnInit {
  deptName :any = "";
 

  constructor(private citizinService: CitizenserviceService) {
   
  }

  ngOnInit() {
    this.citizinService.deptName$.subscribe((message) => {
      this.deptName = message;
      console.log(this.deptName);
    });
  }
 
}
