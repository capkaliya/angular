import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CitizenserviceService {
 _deptName = new Subject();
deptName$ = this._deptName.asObservable();
  constructor() { }
  communicateDept(msg:String){
    this._deptName.next(msg);
  }
}
