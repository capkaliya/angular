import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-complain',
  templateUrl: './transfer-complain.component.html',
  styleUrls: ['./transfer-complain.component.css']
})
export class TransferComplainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
