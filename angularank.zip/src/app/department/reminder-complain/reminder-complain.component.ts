import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reminder-complain',
  templateUrl: './reminder-complain.component.html',
  styleUrls: ['./reminder-complain.component.css']
})
export class ReminderComplainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
