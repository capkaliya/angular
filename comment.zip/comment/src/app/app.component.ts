import { Component, AfterViewInit, ViewChild, ElementRef, OnInit, Output, EventEmitter, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],

})
export class AppComponent implements OnInit {
    comments: Array<object> = [];
    count: number;
    constructor() { }
  
  
    ngOnInit() {
      this.count = 0;
    }
   
    receiveComment($event) {
      this.comments = $event;
      this.count = this.comments.length;
      console.log(this.comments)
    }

  
  
    recieveCount($event) {
      this.comments = $event;
      this.count = this.comments.length;
    }
  
  
  }

