import { Component, AfterViewInit, ViewChild, ElementRef, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-commentbox',
  templateUrl: './commentbox.component.html',
  styleUrls: ['./commentbox.component.css']
})
export class CommentboxComponent implements OnInit {

  public show:boolean = false;
  // count:Observable<any>
  // // constructor(private service : CitizenService){
  // //   this.count = this.service.getCount()

  // // }
  commentForm: FormGroup 
  commentInfo: Array<object> = [];
  commentTxt : String
  submitted: Boolean = false;
  public id = 0;
  @Output() usercomment = new EventEmitter();
  toggle() {
    this.show = !this.show;
  }

  constructor(private formBuilder: FormBuilder) { }


  ngOnInit() {
    console.log()
    this.createForm();
  }


  createForm() {
    this.commentForm = this.formBuilder.group({
      comment: ['']
    });
  }


  onSubmit() {
   
   
      this.commentInfo.push({
        commentId : this.id++,
        currentDate : new Date(),
        commentTxt: this.commentForm.controls['comment'].value,
        replyComment: []
      });
    
      this.usercomment.emit(this.commentInfo);
    
  }



}
