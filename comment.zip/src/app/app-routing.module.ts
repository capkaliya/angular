import { CommentsComponent } from './comments/comments.component';
import { CommentboxComponent } from './commentbox/commentbox.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: 'first-component', component: CommentboxComponent },
  { path: 'second-component', component: CommentsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
