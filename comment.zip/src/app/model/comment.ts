export class Comment {
    commentId :any
    currentDate : any
    commentTxt: any
    replyComment: any
}
