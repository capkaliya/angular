import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-childbox',
  templateUrl: './childbox.component.html',
  styleUrls: ['./childbox.component.css']
})
export class ChildboxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
